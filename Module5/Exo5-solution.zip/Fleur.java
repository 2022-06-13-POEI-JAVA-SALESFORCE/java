package tp5;

public class Fleur extends MereNature {

	private String signification;
	
	
	public Fleur(String name, String color, String signification) {
		super(name, color);
		this.signification = signification;
	}
	
	public String getSignification() {
		return signification;
	}
	public void setSignification(String signification) {
		this.signification = signification;
	}
	@Override
	public void presentation(String text) {
		super.presentation(text);		
		System.out.println("Cette fleur signifie " + this.signification);
	}
}
