package tp5;

public class Jardin {

	public static void main(String[] args) {

		Fleur tulipe = new Fleur("tulipe", "jaune", "jolie fleur des pays-bas");
		Legume haricot = new Legume("haricot", "rouge", "printemps");
		Plante herbe = new Plante("herbe", "vert", 10, 10);

		System.out.println("Vous venez d'acheter : ");
		tulipe.presentation("Une fleur ");
		haricot.presentation("Un l�gume ");
		herbe.presentation("Une plante ");

	}

}
