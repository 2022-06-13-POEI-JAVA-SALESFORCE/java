package tp5;

public class Legume extends MereNature {


	private String saison;
	

	public Legume(String name, String color, String saison) {
		super(name, color);
		this.saison = saison;
	}

	public String getSaison() {
		return saison;
	}

	public void setSaison(String saison) {
		this.saison = saison;
	}
	@Override
	public void presentation(String text) {
		super.presentation(text);		
		System.out.println("Ce l�gume se plante en " + this.saison);
	}
}
