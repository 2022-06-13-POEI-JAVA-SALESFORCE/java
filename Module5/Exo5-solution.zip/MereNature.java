package tp5;

public class MereNature {

	protected String name;
	protected String color;

	public MereNature(String name, String color) {
		super();
		this.name = name;
		this.color = color;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void presentation(String text) {
		System.out.println(text + this.name + " qui est " + this.color);
	}
	
}
