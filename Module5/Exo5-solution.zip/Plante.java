package tp5;

public class Plante extends MereNature {

	private int hauteur;
	private int age;
	
	
	public Plante(String name, String color, int hauteur, int age) {
		super(name, color);
		this.age = age;
		this.hauteur = hauteur;
	}
	
	public int getHauteur() {
		return hauteur;
	}
	public void setHauteur(int hauteur) {
		this.hauteur = hauteur;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public void presentation(String text) {
		super.presentation(text);		
		System.out.println("Cette plante est d une hauteur de "+ this.hauteur + " et �g�e de " + this.age);
	}
}
