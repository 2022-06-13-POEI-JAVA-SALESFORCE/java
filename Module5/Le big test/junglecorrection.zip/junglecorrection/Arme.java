package junglecorrection;

public class Arme {
	
	private String nomAttaque;
	private int nbDegats;
	
	public Arme(String nomAttaque, int nbDegats) {
		super();
		this.nomAttaque = nomAttaque;
		this.nbDegats = nbDegats;
	}

	public String getNomAttaque() {
		return nomAttaque;
	}

	public void setNomAttaque(String nomAttaque) {
		this.nomAttaque = nomAttaque;
	}

	public int getNbDegats() {
		return nbDegats;
	}

	public void setNbDegats(int nbDegats) {
		this.nbDegats = nbDegats;
	}

}