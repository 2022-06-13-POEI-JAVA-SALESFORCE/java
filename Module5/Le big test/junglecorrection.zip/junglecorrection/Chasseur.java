package junglecorrection;

import java.util.Random;

public class Chasseur extends Combattant{
	
	private static int nbCoupFeu = 0;

	public Chasseur(String nom, Arme arme, int frenesie) {
		
		super(nom, arme, frenesie);
		
	}
	
	public void boire() {
		
		if(new Random().nextInt(10) + 1 >= 8) {
			
			this.frenesie = this.frenesie + 1;
			
		}
		
	}

	public static int getNbCoupFeu() {
		return nbCoupFeu;
	}

	public static void setNbCoupFeu(int nbCoupFeu) {
		Chasseur.nbCoupFeu = nbCoupFeu;
	}

}