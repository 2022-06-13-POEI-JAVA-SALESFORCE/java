package junglecorrection;

public class Combattant {
	
	protected String nom;
	protected int nbPtsVie = 100;
	protected Arme arme;
	protected int frenesie;
	
	public Combattant(String nom, Arme arme, int frenesie) {
		super();
		this.nom = nom;
		this.arme = arme;
		this.frenesie = frenesie;
	}
	
	// Attaque d'un combattant
	public void attaquer(Combattant combattant) {
		
		combattant.setNbPtsVie(combattant.getNbPtsVie() - this.getArme().getNbDegats() * this.getFrenesie());
		
		if (combattant.getNbPtsVie() <= 0) {

			System.out.println("Une mort dans le simulateur");
			
			if(combattant instanceof Raptor)
				System.out.println("Il s'agit d'un raptor");
			else
				System.out.println("Il s'agit d'un chasseur");

		}
		
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getNbPtsVie() {
		return nbPtsVie;
	}

	public void setNbPtsVie(int nbPtsVie) {
		this.nbPtsVie = nbPtsVie;
	}

	public Arme getArme() {
		return arme;
	}

	public void setArme(Arme arme) {
		this.arme = arme;
	}

	public int getFrenesie() {
		return frenesie;
	}

	public void setFrenesie(int frenesie) {
		this.frenesie = frenesie;
	}

}
