package junglecorrection;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Arme croc = new Arme("Koud'kroc", 10);
		Arme fusil = new Arme("Koud'fusil", 5);

		Raptor raptor = new Raptor("Rapzilla", croc, 5);
		Chasseur chasseur1 = new Chasseur("Bob la brute", fusil, 1);
		Chasseur chasseur2 = new Chasseur("Bob le bon", fusil, 1);
		Chasseur chasseur3 = new Chasseur("Bob le truant", fusil, 1);

		System.out.println("------ ENTRER DANS LA SIMULATION ------");
		System.out.println("1 - Lancer le programme");
		System.out.println("0 - Quitter");
		System.out.println("-----------------------------------");

		Scanner scanner = new Scanner(System.in);
		String reponse = scanner.nextLine();
		if (!reponse.equals("1")) {
			System.out.println("Fermeture du programme.");
			System.exit(0);
		}

		// le combat
		boolean attaqueRaptor = false;
		// tant que le raptor est en vie et que les trois chasseurs le sont aussi
		while (raptor.getNbPtsVie() > 0
				&& (chasseur1.getNbPtsVie() > 0 || chasseur2.getNbPtsVie() > 0 || chasseur3.getNbPtsVie() > 0)) {
			
			attaqueRaptor = false;
			
			// attaque du chasseur 1
			if (chasseur1.getNbPtsVie() > 0) {

				chasseur1.attaquer(raptor);
				chasseur1.boire();
				Chasseur.setNbCoupFeu(Chasseur.getNbCoupFeu() + 1);

			}

			// attaque du chasseur 2
			if (chasseur2.getNbPtsVie() > 0) {

				chasseur2.attaquer(raptor);
				chasseur2.boire();
				Chasseur.setNbCoupFeu(Chasseur.getNbCoupFeu() + 1);

			}

			//attaque du chasseur 3
			if (chasseur3.getNbPtsVie() > 0) {

				chasseur3.attaquer(raptor);
				chasseur3.boire();
				Chasseur.setNbCoupFeu(Chasseur.getNbCoupFeu() + 1);

			}
			
			// attaque du raptor
			if (raptor.getNbPtsVie() > 0) {
				
				if(chasseur1.getNbPtsVie() > 0 && !attaqueRaptor) {
					
					raptor.attaquer(chasseur1);
					attaqueRaptor = true;
					
				}else if(chasseur2.getNbPtsVie() > 0 && !attaqueRaptor) {
					
					raptor.attaquer(chasseur2);
					attaqueRaptor = true;
					
				}else {
					
					raptor.attaquer(chasseur3);
				}				

			}
			
			// affichage du message d'information
			System.out.println("PV raptor : "+raptor.getNbPtsVie());
			System.out.println("PV chasseur 1 : "+chasseur1.getNbPtsVie());
			System.out.println("PV chasseur 2 : "+chasseur2.getNbPtsVie());
			System.out.println("PV chasseur 3 : "+chasseur3.getNbPtsVie());
			
			// contr�le si le jour se l�ve
			if(Chasseur.getNbCoupFeu() >= 6) {
				
				do {
					
					System.out.println("------ LE JOUR SE LEVE ------");
					System.out.println("------ REPRENDRE LE COMBAT ? ------");
					System.out.println("------ 1 - Oui ------");
					System.out.println("------ 0 - Non ------");
					System.out.println("-----------------------------------");
					
					reponse = scanner.nextLine();
					
					if(!reponse.equals("1")) {
						System.out.println("------ OK. DITES NOUS QUAND VOUS ETES PRET ------");
					}
					
				}while(!reponse.equals("1"));
				
				Chasseur.setNbCoupFeu(0);
				
			}

		}
		
		scanner.close();
		
		if(raptor.getNbPtsVie() > 0) {
			// victoire du raptor
			System.out.println("Les 3 chasseurs sont morts, victoire du raptor et de son attaque "+raptor.getArme().getNomAttaque()+" !");
		}else if(chasseur1.getNbPtsVie() > 0 || chasseur2.getNbPtsVie() > 0 || chasseur3.getNbPtsVie() > 0 ) {
			System.out.println("Le raptor est mort, victoire des chasseurs et de leur attaque "+chasseur1.getArme().getNomAttaque()+" !");
		}else {
			System.out.println("Egalit� !");
		}

	}

}
