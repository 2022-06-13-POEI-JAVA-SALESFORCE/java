package junglecorrection;

public class Raptor extends Combattant{

	public Raptor(String nom, Arme arme, int frenesie) {
		super(nom, arme, frenesie);
	}
	
}