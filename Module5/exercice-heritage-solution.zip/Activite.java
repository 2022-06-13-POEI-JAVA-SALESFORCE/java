package exercice5bis;

public class Activite {
	private String name;
	private String town;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public Activite(String name, String town) {
		super();
		this.name = name;
		this.town = town;
	}

	public void presentation() {
		System.out.print(name + "est ouvert dans la ville de " + town); 
	}
	

}
