package exercice5bis;

public class Game {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MiniGolf miniParty = new MiniGolf("Mini party", "Lens", 100);
		LaserGame lgeevolution = new LaserGame("LGE Evolution", "Limoges", 10);
		
		miniParty.presentation();
		lgeevolution.presentation();
		
	}

}
