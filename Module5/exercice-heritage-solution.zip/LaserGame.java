package exercice5bis;

public class LaserGame extends Activite{
	
	private int game;

		public LaserGame(String name, String town, int game) {
		super(name, town);
		this.game = game;
	}

	public int getGame() {
		return game;
	}

	public void setGame(int game) {
		this.game = game;
	}
	
	@Override
	public void presentation() {
		super.presentation();
		System.out.println(" et met � sa disposition " + game + " balles."); 
	}

}
