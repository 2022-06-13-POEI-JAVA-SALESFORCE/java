package exercice5bis;

public class MiniGolf extends Activite {
	
	private int ball;

	public MiniGolf(String name, String town, int ball) {
		super(name, town);
		this.ball = ball;
	}

	public int getBall() {
		return ball;
	}

	public void setBall(int ball) {
		this.ball = ball;
	}
	
	@Override
	public void presentation() {
		super.presentation();
		System.out.println(" et met � sa disposition " + ball + " balles."); 
	}

}
