package tp6;

public interface ArtisteInterface {
	
	void echauffement();
	void jouer();

}
