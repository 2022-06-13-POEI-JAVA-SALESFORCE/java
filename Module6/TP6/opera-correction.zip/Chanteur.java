package tp6;

public class Chanteur extends Artiste{
	
	private String type;

	public Chanteur(String nom, String type) {
		super(nom);
		this.type = type;
	}
	
	public void echauffement() {
		
		if (this.type.equals("soprano")) {
			System.out.println("Je m'huile les cordes vocales");
		}else if(this.type.equals("t�nor")) {
			System.out.println("Je fais des notes graves pendant 30 secondes");
		}else{
			System.out.println("Nous avons un chanteur de type inconnu");
		}
		
	}
	
	public void jouer() {
		
		if (this.type.equals("soprano")) {
			System.out.println(this.nom + "� mi amooooooor����� tuuu solv�� tiiiiiii");
		}else if(this.type.equals("t�nor")) {
			System.out.println(this.nom + "����� sol����miiiiiiiiooooooooooooo");
		}else {
			System.out.println("J'ai la voix cass�e");
		}
		
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
