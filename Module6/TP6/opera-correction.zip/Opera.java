package tp6;

import java.util.GregorianCalendar;

public class Opera {
	
	public static void main(String[] args) {
		
		Chanteur kienast = new Chanteur("Kienast", "t�nor");
		Chanteur haroche = new Chanteur("Haroche", "soprano");
		Violoncelliste artioche = new Violoncelliste("Artioche", new GregorianCalendar(2005,9,15));
		
		System.out.println("-------- Pr�parez vous --------");
		
		// �chauffement
		kienast.echauffement();
		haroche.echauffement();
		artioche.echauffement();
		
		System.out.println("-------- ACTE 1 --------");
		
		// jouer
		kienast.jouer();
		artioche.jouer();
		haroche.jouer();
	
	}
	
}
