package tp6;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Violoncelliste extends Artiste {

	private GregorianCalendar dateEntree;

	public Violoncelliste(String nom, GregorianCalendar dateEntree) {
		super(nom);
		this.dateEntree = dateEntree;
	}

	public void echauffement() {

		if(this.dateEntree.get(Calendar.YEAR) < 2010) {
			System.out.println("Je peux m'�chauffer avec le violon d'or");
		}else {
			System.out.println("Je peux m'�chauffer avec le violon classique");
		}

	}

	public void jouer() {

		System.out.println(this.nom + " : fililouuuuu lilouulilooouliloouuuuuu");
		System.out.println("Vive le violon");

	}

	public GregorianCalendar getDateEntree() {
		return dateEntree;
	}

	public void setDateEntree(GregorianCalendar dateEntree) {
		this.dateEntree = dateEntree;
	}

}