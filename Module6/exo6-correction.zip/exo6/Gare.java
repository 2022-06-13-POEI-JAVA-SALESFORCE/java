package exo6;

public class Gare extends Propriete{
	
	private int nbTrain;
	private int nbLocomotive;
	
	public Gare(int prixAchat, String nom, int nbTrain, int nbLocomotive) {
		super(prixAchat, nom);
		this.nbTrain = nbTrain;
		this.nbLocomotive = nbLocomotive;
	}
	
	public int payerLoyer() {
		
		return (this.nbTrain + this.nbLocomotive) * this.prixAchat;
		
	}

	public int getNbTrain() {
		return nbTrain;
	}

	public void setNbTrain(int nbTrain) {
		this.nbTrain = nbTrain;
	}

	public int getNbLocomotive() {
		return nbLocomotive;
	}

	public void setNbLocomotive(int nbLocomotive) {
		this.nbLocomotive = nbLocomotive;
	}

}
