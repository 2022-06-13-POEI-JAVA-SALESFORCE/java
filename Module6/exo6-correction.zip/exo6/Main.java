package exo6;

public class Main {

	public static void main(String[] args) {
		
		Gare gare = new Gare(150,"Ma gare",5,1);
		Terrain terrain = new Terrain(50,"Mon terrain","rouge",50);
		
		gare.payerLoyer();
		terrain.payerLoyer();

	}

}
