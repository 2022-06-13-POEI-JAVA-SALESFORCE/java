package exo6;

public interface PayerLoyerInterface {

	int payerLoyer();
	
}