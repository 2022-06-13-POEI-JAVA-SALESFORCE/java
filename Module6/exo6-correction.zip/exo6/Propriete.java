package exo6;

public abstract class Propriete implements PayerLoyerInterface {
	
	protected int prixAchat;
	private String nom;
	private Joueur joueur;
	
	public Propriete(int prixAchat, String nom) {
		super();
		this.prixAchat = prixAchat;
		this.nom = nom;
	}

	public int getPrixAchat() {
		return prixAchat;
	}

	public void setPrixAchat(int prixAchat) {
		this.prixAchat = prixAchat;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Joueur getJoueur() {
		return joueur;
	}

	public void setJoueur(Joueur joueur) {
		this.joueur = joueur;
	}

}