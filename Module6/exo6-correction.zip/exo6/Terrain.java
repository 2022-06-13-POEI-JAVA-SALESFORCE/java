package exo6;

public class Terrain extends Propriete{

	private String couleur;
	private int coutConstruction;
	
	public Terrain(int prixAchat, String nom, String couleur, int coutConstruction) {
		super(prixAchat, nom);
		this.couleur = couleur;
		this.coutConstruction = coutConstruction;
	}
	
	public int payerLoyer() {
		
		return this.coutConstruction + this.prixAchat;
		
	}

	public String getCouleur() {
		return couleur;
	}

	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}

	public int getCoutConstruction() {
		return coutConstruction;
	}

	public void setCoutConstruction(int coutConstruction) {
		this.coutConstruction = coutConstruction;
	}
	
}
