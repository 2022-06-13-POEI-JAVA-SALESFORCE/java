package module6;

public class Gare extends Propriete{
	
	private int nbTrain;
	private int nbLocomotive;
	
	public Gare(String couleur, int coutConstruction, int nbTrain, int nbLocomotive) {
		super(couleur, coutConstruction);
		this.nbTrain = nbTrain;
		this.nbLocomotive = nbLocomotive;
	}

	public int getNbTrain() {
		return nbTrain;
	}

	public void setNbTrain(int nbTrain) {
		this.nbTrain = nbTrain;
	}

	public int getNbLocomotive() {
		return nbLocomotive;
	}

	public void setNbLocomotive(int nbLocomotive) {
		this.nbLocomotive = nbLocomotive;
	}
	
	

}
