package module6;

public class Main {

	public static void main(String[] args) {
		
		Joueur joueur = new Joueur("Bob","rouge");
		Propriete propriete = new Propriete("Ma propri�t�",150);
		
	}

}
