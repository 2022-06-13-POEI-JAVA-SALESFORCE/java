package module6;

public class Propriete {
	
	private String couleur;
	private int coutConstruction;
	
	public Propriete(String couleur, int coutConstruction) {
		super();
		this.couleur = couleur;
		this.coutConstruction = coutConstruction;
	}
	
	public String getCouleur() {
		return couleur;
	}
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	public int getCoutConstruction() {
		return coutConstruction;
	}
	public void setCoutConstruction(int coutConstruction) {
		this.coutConstruction = coutConstruction;
	}
	
	

}
