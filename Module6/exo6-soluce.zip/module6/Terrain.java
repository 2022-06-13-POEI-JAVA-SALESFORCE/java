package module6;

public class Terrain extends Propriete{
	
	private String couleur;
	private int coutConstruction;
	
	public Terrain(String couleur, int coutConstruction, String couleur2, int coutConstruction2) {
		super(couleur, coutConstruction);
		couleur = couleur2;
		coutConstruction = coutConstruction2;
	}

	public String getCouleur() {
		return couleur;
	}

	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}

	public int getCoutConstruction() {
		return coutConstruction;
	}

	public void setCoutConstruction(int coutConstruction) {
		this.coutConstruction = coutConstruction;
	}
	
	

}
