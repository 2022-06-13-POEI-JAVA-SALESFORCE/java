package tp8;

public class Client extends Humain{
	
	private int tailleFamille;
	
	public Client(String nom, String prenom, int tailleFamille) {
		super(nom, prenom);
		this.tailleFamille = tailleFamille;
	}

	public int getTailleFamille() {
		return tailleFamille;
	}

	public void setTailleFamille(int tailleFamille) {
		this.tailleFamille = tailleFamille;
	}

}
