package tp8;

public class Produit {
	
	protected String nom;
	protected String couleur;
	protected int stock;
	
	public Produit(String nom, String couleur, int stock) {
		super();
		this.nom = nom;
		this.couleur = couleur;
		this.stock = stock;
	}
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getCouleur() {
		return couleur;
	}
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}

}