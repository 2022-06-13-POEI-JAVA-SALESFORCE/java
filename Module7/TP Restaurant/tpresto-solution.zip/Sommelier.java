package tp8;

public class Sommelier extends Humain{
	
	private int anciennete;
	private Vin vinSelectionne;

	public Sommelier(String nom, String prenom, int anciennete) {
		super(nom, prenom);
		this.anciennete = anciennete;
	}
	
	public void baisserStock() {
		this.vinSelectionne.setStock(this.vinSelectionne.getStock() - 1);
		this.vinSelectionne.getViandeSelectionnee().setStock(this.vinSelectionne.getViandeSelectionnee().getStock() - 1);
	}

	public int getAnciennete() {
		return anciennete;
	}

	public void setAnciennete(int anciennete) {
		this.anciennete = anciennete;
	}

	public Vin getVinSelectionne() {
		return vinSelectionne;
	}

	public void setVinSelectionne(Vin vinSelectionne) {
		this.vinSelectionne = vinSelectionne;
	}

}