package tp8;

public class Viande extends Produit{

	private String provenance;

	public Viande(String nom, String couleur, String provenance, int stock) {
		super(nom, couleur, stock);
		this.provenance = provenance;
	}
	
	public static void presentation() {
		
		System.out.println("Nos viandes assaisonn�es avec amour");
		
	}

	public String getProvenance() {
		return provenance;
	}

	public void setProvenance(String provenance) {
		this.provenance = provenance;
	}
	
}
