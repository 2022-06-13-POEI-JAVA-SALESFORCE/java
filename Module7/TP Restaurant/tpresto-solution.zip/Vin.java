package tp8;

import java.util.GregorianCalendar;

public class Vin extends Produit{
	
	private GregorianCalendar millesime;
	private int niveauBouteille;
	private Viande viandeSelectionnee;
	
	public Vin(String nom, GregorianCalendar millesime, String couleur, int niveauBouteille, int stock) {
		super(nom,couleur,stock);
		this.millesime = millesime;
		this.niveauBouteille = niveauBouteille;
	}
	
	public static void presentation() {
		
		System.out.println("Nos vins sont servis � temp�rature ambiante");
		
	}
	
	public GregorianCalendar getMillesime() {
		return millesime;
	}
	public void setMillesime(GregorianCalendar millesime) {
		this.millesime = millesime;
	}
	
	public int getNiveauBouteille() {
		return niveauBouteille;
	}
	public void setNiveauBouteille(int niveauBouteille) {
		this.niveauBouteille = niveauBouteille;
	}

	public Viande getViandeSelectionnee() {
		return viandeSelectionnee;
	}

	public void setViandeSelectionnee(Viande viandeSelectionnee) {
		this.viandeSelectionnee = viandeSelectionnee;
	}

}
