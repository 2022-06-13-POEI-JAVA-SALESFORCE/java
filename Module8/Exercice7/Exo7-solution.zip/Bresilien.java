package exo7;

import java.util.ArrayList;

public class Bresilien extends Client {

	private String main;
	private static ArrayList<Bresilien> bresiliens = new ArrayList<>();
	
	//constructeur
	public Bresilien(String name, String firstName, Civilite sexe, int fortune, String main) {
		super(name, firstName, sexe, fortune);
		this.main = main;
		bresiliens.add(this);

	}

	

	//Assertions 
	public String getMain() {
		return main;
	}

	public void setMain(String main) {
		this.main = main;
	}

	public static ArrayList<Bresilien> getBresiliens() {
		return bresiliens;
	}

	public static void setBresiliens(ArrayList<Bresilien> bresiliens) {
		Bresilien.bresiliens = bresiliens;
	}
	
	
}
