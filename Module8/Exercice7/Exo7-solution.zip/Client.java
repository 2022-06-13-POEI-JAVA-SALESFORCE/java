package exo7;

import java.util.ArrayList;


public class Client {

	private String name;
	private String firstName;
	private Civilite sexe;
	private int fortune;
	private static ArrayList<Client> clients = new ArrayList<>();

	public enum Civilite {
		Homme, Femme, autre
	}

	// Constructeur
	public Client(String name, String firstName, Civilite sexe, int fortune) {
		super();
		this.name = name;
		this.firstName = firstName;
		this.sexe = sexe;
		this.fortune = fortune;
		clients.add(this);
	}

	public static <C extends Client> C getMeilleurClient(ArrayList<C> clients) {
		C meilleurClient = null;
		int fortune = 0;
		for (C Client : clients) {
			if (Client.getFortune() > fortune) {
				fortune = Client.getFortune();
				meilleurClient = Client;
			}
		}
		return meilleurClient;
	}
	
	// Affiche le meilleur client pass� en param�tre
	public static void afficherMeilleurClient(Client client, String nationalite) {
				
		System.out.println("------------------------- NOTRE MEILLEUR CLIENT"+nationalite+" EST --------------------------");
		System.out.println("---------" + client.sexe + ", " + client.name+" "
				+ client.firstName + " avec une fortune estim�e � " + client.fortune + " euros ---------");
		System.out.println("----------------------------------------------------------------------------");
		
	}
	

	public static ArrayList<Client> getClients() {
		return clients;
	}

	public static void setClients(ArrayList<Client> clients) {
		Client.clients = clients;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public int getFortune() {
		return fortune;
	}

	public void setFortune(int fortune) {
		this.fortune = fortune;
	}

	public Civilite getSexe() {
		return sexe;
	}

	public void setSexe(Civilite sexe) {
		this.sexe = sexe;
	}

}
