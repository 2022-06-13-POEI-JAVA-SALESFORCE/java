package exo7;

import java.util.ArrayList;


public class Japonais extends Client {

	private String couleur;
	private static ArrayList<Japonais> japonais = new ArrayList<>();
	
	//constructeur
	public Japonais(String name, String firstName, Civilite sexe, int fortune, String couleur) {
		super(name, firstName, sexe, fortune);
		this.couleur = couleur;
		japonais.add(this);

	}
	
	//assertions
	public String getCouleur() {
		return couleur;
	}

	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}

	public static ArrayList<Japonais> getJaponais() {
		return japonais;
	}

	public static void setJaponais(ArrayList<Japonais> japonais) {
		Japonais.japonais = japonais;
	}
	
	
}
