package exo7;

import exo7.Client.Civilite;

public class Main {

	public static void main(String[] args) {

		new Japonais("Hoshimako", "Kayazima", Civilite.Homme, 400000, "rouge");
		new Japonais("Watishari", "Teyon", Civilite.Femme, 1500000, "vert");
		new Japonais("Shibonduyakomatishimoyatori", "Ne", Civilite.Homme, 850000, "violet");

		new Bresilien("Muchabuuenneeeee", "Carlitoooo", Civilite.autre, 20, "Gaucher");
		new Bresilien("Ricuerdo", "Gabrielle", Civilite.Femme, 55, "Gauch�re");

		Client meilleurClient = Client.getMeilleurClient(Client.getClients());
		Client.afficherMeilleurClient(meilleurClient,"");
		
		Japonais meilleurClientJaponais = Japonais.getMeilleurClient(Japonais.getJaponais());
		Client.afficherMeilleurClient(meilleurClientJaponais," JAPONAIS");
		
		Bresilien meilleurClientBresilien = Bresilien.getMeilleurClient(Bresilien.getBresiliens());
		Client.afficherMeilleurClient(meilleurClientBresilien, " BRESILIEN");
		
	}

}
