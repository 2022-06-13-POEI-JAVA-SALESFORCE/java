package castellet;

import java.util.Scanner;

public class Course {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		String reponseProgramme = "0";
		do {

			System.out.println("--------- GRAND PRIX DU CASTELLET ---------");
			System.out.println("1 : Ajouter une �curie");
			System.out.println("2 : Ajouter une voiture");
			System.out.println("3 : Ajouter un pilote");
			System.out.println("4 : Lister les �curies");
			System.out.println("5 : Lister les voitures");
			System.out.println("6 : Lister les pilotes");
			System.out.println("7 : Lancer la course");
			System.out.println("-------------------------------------------");

			reponseProgramme = scanner.nextLine();

			// CHOIX 1 - Ajouter une �curie
			if (reponseProgramme.equals("1")) {

				System.out.println("--------- Ins�rez le nom de l'�curie ---------");
				String nom = scanner.nextLine();

				System.out.println("--------- Ins�rez la nationalit� de l'�curie ---------");
				String nationalite = scanner.nextLine();

				new Ecurie(nom, nationalite);

			}

			// CHOIX 2 - Ajouter une voiture
			if (reponseProgramme.equals("2")) {

				// si au moins une �curie existe
				if (!Ecurie.getEcuries().isEmpty()) {

					System.out.println("--------- Ins�rez le nom de la voiture ---------");
					String nom = scanner.nextLine();

					System.out.println("--------- Ins�rez la nationalit� de la voiture ---------");
					String nationalite = scanner.nextLine();

					System.out.println("--------- A quelle �curie appartient-elle ? ---------");
					Protagoniste.listerProtagoniste(Ecurie.getEcuries());
					int ecurie = scanner.nextInt();

					// Ajout de la voiture � l'�curie
					Ecurie.getEcuries().get(ecurie).getVoitures().add(new Voiture(nom, nationalite));

				} else {
					// si on ne trouve pas d'�curie
					System.out.println("Veuillez d'abord ajouter une �curie");
				}

			}

			// CHOIX 3 - Ajouter un pilote
			if (reponseProgramme.equals("3")) {

				// si au moins une �curie et une voiture existe
				if (!Ecurie.getEcuries().isEmpty() && !Voiture.getVoitures().isEmpty()) {

					System.out.println("--------- Ins�rez le nom du pilote ---------");
					String nom = scanner.nextLine();

					System.out.println("--------- Ins�rez la nationalit� du pilote ---------");
					String nationalite = scanner.nextLine();

					System.out.println("--------- A quelle �curie appartient-il ? ---------");
					Protagoniste.listerProtagoniste(Ecurie.getEcuries());
					int ecurie = scanner.nextInt();

					// Ajout du pilote � l'�curie
					Pilote pilote = new Pilote(nom, nationalite);
					Ecurie.getEcuries().get(ecurie).getPilotes().add(pilote);
					pilote.setEcurie(Ecurie.getEcuries().get(ecurie));

				} else {
					// si on ne trouve pas d'�curie ou de voiture
					System.out.println("Veuillez d'abord ajouter une �curie et une voiture");
				}

			}

			// CHOIX 4 - Lister les �curies
			if (reponseProgramme.equals("4")) {

				Protagoniste.listerProtagoniste(Ecurie.getEcuries());

			}

			// CHOIX 5 - Lister les voitures
			if (reponseProgramme.equals("5")) {

				Protagoniste.listerProtagoniste(Voiture.getVoitures());

			}
			
			// CHOIX 6 - Lister les pilotes
			if (reponseProgramme.equals("6")) {

				Protagoniste.listerProtagoniste(Pilote.getPilotes());

			}
			
			// CHOIX 7 - Lancement de la course
			if(reponseProgramme.equals("7")) {
				
				// Si j'ai des pilotes
				if(!Pilote.getPilotes().isEmpty()) {
					
					for(Pilote pilote : Pilote.getPilotes()) {
						
						System.out.println(pilote.getNom()+" est dans son baquet. Quelle voiture a-t-il choisi aujourd'hui ?");
						
						int index = 0;
						for(Voiture voiture : pilote.getEcurie().getVoitures()) {
							
							System.out.println("------ A sa disposition ------");
							System.out.println(index+ " : "+voiture.getNom());
							index++;
						}
						int choixVoiture = scanner.nextInt();
						pilote.setVoiture(pilote.getEcurie().getVoitures().get(choixVoiture));
						
					}
					
					// affichage final
					System.out.println("Le Grand Prix de France va pouvoir commencer !");
					
					for(Ecurie ecurie : Ecurie.getEcuries()) {
						
						System.out.println("L'�curie "+ecurie.getNom()+" et ses pilotes :");
						
						for(Pilote pilote : ecurie.getPilotes()) {
							
							System.out.println(pilote.getNom()+" au volant de sa "+pilote.getVoiture().getNom());
							
						}
						
					}
					
				}
				
				break;
				
			}

		} while (!reponseProgramme.equals("7"));
		
		scanner.close();
		System.out.println("Fermeture du programme");

	}

}
