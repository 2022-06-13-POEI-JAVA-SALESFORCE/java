package castellet;

import java.util.ArrayList;

public class Pilote extends Protagoniste{
	
	private static ArrayList<Pilote> pilotes = new ArrayList<>();
	private Ecurie ecurie;
	private Voiture voiture;

	public Pilote(String nom, String nationalite) {
		super(nom, nationalite);
		pilotes.add(this);
	}

	public static ArrayList<Pilote> getPilotes() {
		return pilotes;
	}

	public static void setPilotes(ArrayList<Pilote> pilotes) {
		Pilote.pilotes = pilotes;
	}

	public Ecurie getEcurie() {
		return ecurie;
	}

	public void setEcurie(Ecurie ecurie) {
		this.ecurie = ecurie;
	}

	public Voiture getVoiture() {
		return voiture;
	}

	public void setVoiture(Voiture voiture) {
		this.voiture = voiture;
	}
	
}
