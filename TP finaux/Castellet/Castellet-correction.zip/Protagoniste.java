package castellet;

import java.util.List;

public class Protagoniste {

	private String nom;
	private String nationalite;

	public Protagoniste(String nom, String nationalite) {

		this.setNom(nom);
		this.setNationalite(nationalite);

	}
	
	// Affiche une liste de protagoniste
	public static <C extends Protagoniste> void listerProtagoniste(List<C> protagonistes) {

		int index = 0;
		for (Protagoniste p : protagonistes) {

			System.out.println(index + " : " + p.nom);
			index++;

		}
		
		if (protagonistes.isEmpty()) {
			System.out.println("Aucune donn�e � afficher");
		}

	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getNationalite() {
		return nationalite;
	}

	public void setNationalite(String nationalite) {
		this.nationalite = nationalite;
	}

}