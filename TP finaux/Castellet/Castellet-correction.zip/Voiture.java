package castellet;

import java.util.ArrayList;

public class Voiture extends Protagoniste{
	
	private static ArrayList<Voiture> voitures = new ArrayList<>();

	public Voiture(String nom, String nationalite) {
		super(nom, nationalite);
		voitures.add(this);
	}

	public static ArrayList<Voiture> getVoitures() {
		return voitures;
	}

	public static void setVoitures(ArrayList<Voiture> voitures) {
		Voiture.voitures = voitures;
	}
	
}
