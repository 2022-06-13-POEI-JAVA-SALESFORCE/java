package pokemon;

public class Attaque {
	
	private String nom;
	private int nbDegats;
	
	public Attaque(String nom, int nbDegats) {
		
		this.setNom(nom);
		this.setNbDegats(nbDegats);
		
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getNbDegats() {
		return nbDegats;
	}

	public void setNbDegats(int nbDegats) {
		this.nbDegats = nbDegats;
	}
	
}
