package pokemon;

import java.util.ArrayList;

public class Carapuce extends Pokemon{
	
	private static ArrayList<Carapuce> carapuces = new ArrayList<>();

	public Carapuce(String nom, int nombrePV) {
		
		super(nom, Type.EAU, nombrePV);
		carapuces.add(this);

	}
	
	// affiche les infos de l'attaque
	@Override
	public void lancerAttaque() {
		
		super.lancerAttaque();
		System.out.println("Tout le monde est mouill�, c'est terrible !");
		
	}

	public static ArrayList<Carapuce> getCarapuces() {
		return carapuces;
	}

	public static void setCarapuces(ArrayList<Carapuce> carapuces) {
		Carapuce.carapuces = carapuces;
	}

}
