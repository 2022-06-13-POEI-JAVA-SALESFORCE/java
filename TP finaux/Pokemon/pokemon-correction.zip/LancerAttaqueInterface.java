package pokemon;

public interface LancerAttaqueInterface {
	
	void lancerAttaque();

}
