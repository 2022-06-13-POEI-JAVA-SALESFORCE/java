package pokemon;

public class Main {

	public static void main(String[] args) {
		
		new Carapuce("Carapuce", 15);
		new Carapuce("Carabaffe", 50);
		new Carapuce("Tortank", 100);
		
		new Salameche("Salameche", 15);
		new Salameche("Reptincelle", 45);
		new Salameche("Dracaufeu", 95);
		
		// afficher le pokemon eau et le pokemon feu avec le plus de PV
		Carapuce carapucePlusPV = Pokemon.getPlusPV(Carapuce.getCarapuces());
		Salameche salamechePlusPV = Pokemon.getPlusPV(Salameche.getSalameches());
		
		carapucePlusPV.presentationPokemonPlusPV();
		salamechePlusPV.presentationPokemonPlusPV();
		
		// je demande l'attaque de mes pokemons
		carapucePlusPV.setAttaque(carapucePlusPV.demanderAttaque());
		salamechePlusPV.setAttaque(salamechePlusPV.demanderAttaque());
		
		// je lance les attaques
		carapucePlusPV.lancerAttaque();
		salamechePlusPV.lancerAttaque();
		
	}

}
