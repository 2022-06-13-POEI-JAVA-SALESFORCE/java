package pokemon;

import java.util.ArrayList;
import java.util.Scanner;

public abstract class Pokemon implements LancerAttaqueInterface{

	private String nom;
	private Type type;
	private int nombrePV;
	private Attaque attaque;

	private static ArrayList<Pokemon> pokemons = new ArrayList<>();

	public enum Type {

		EAU, FEU, PLANTE

	}

	public Pokemon(String nom, Type type, int nombrePV) {
		super();
		this.nom = nom;
		this.type = type;
		this.nombrePV = nombrePV;
		pokemons.add(this);
	}

	// Pr�sente un pokemon
	public void presentationPokemonPlusPV() {

		System.out.println(this.nom + " est le pokemon de type " + this.type + " avec le plus de PV");

	}

	// Renvoie le pokemon avec le plus de PV
	public static <C extends Pokemon> C getPlusPV(ArrayList<C> pokemons) {

		C pokemonPlusPV = null;
		int pvMax = 0;

		for (C pokemon : pokemons) {

			if (pokemon.getNombrePV() > pvMax) {

				pvMax = pokemon.getNombrePV();
				pokemonPlusPV = pokemon;

			}

		}

		return pokemonPlusPV;

	}

	// Renvoie l'attaque d'un pokemon selon les choix de l'utilisateur
	public Attaque demanderAttaque() {

		// demander l'attaque du pokemon avec le plus de pv
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("Quelle est l'attaque de " + this.nom + " ?");
		String attaqueNom = scanner.nextLine();
		System.out.println("Combien de d�gats inflige l'attaque " + attaqueNom);
		int attaqueDgts = scanner.nextInt();

		// cr�er l'attaque
		Attaque attaque = new Attaque(attaqueNom, attaqueDgts);
		
		return attaque;

	}
	
	// affiche les infos de l'attaque
	public void lancerAttaque() {
		
		System.out.println(this.nom+ " lance l'attaque "+this.attaque.getNom());
		
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public int getNombrePV() {
		return nombrePV;
	}

	public void setNombrePV(int nombrePV) {
		this.nombrePV = nombrePV;
	}

	public Attaque getAttaque() {
		return attaque;
	}

	public void setAttaque(Attaque attaque) {
		this.attaque = attaque;
	}

}
