package pokemon;

import java.util.ArrayList;

public class Salameche extends Pokemon{
	
	private static ArrayList<Salameche> salameches = new ArrayList<>();

	public Salameche(String nom, int nombrePV) {
		
		super(nom, Type.FEU, nombrePV);
		salameches.add(this);
		
	}
	
	// affiche les infos de l'attaque
	@Override
	public void lancerAttaque() {
		
		super.lancerAttaque();
		System.out.println("Chaud chaud, �a brule !");
		
	}

	public static ArrayList<Salameche> getSalameches() {
		return salameches;
	}

	public static void setSalameches(ArrayList<Salameche> salameches) {
		Salameche.salameches = salameches;
	}
	
}
